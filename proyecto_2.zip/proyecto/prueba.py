#!/usr/bin/python3

from tkinter import *

app = Tk()
app.attributes()
app.mainloop()