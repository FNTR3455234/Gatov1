from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from juego_ignorancia import *
from ed_categoria import *
turno=1
correcto=0
#Crea las variables para cada boton
g1=""
g2=""
g3=""
g4=""
g5=""
g6=""
g7=""
g8=""
g9=""
def gato():
    pant=Toplevel()
    pant.resizable(1,1)
    pant.config(bg="light sky blue")
    pant.title("carrera de la ignorancia")
    pant.geometry("1200x700")
   

    eti=Label(pant,bg="light sky blue",text="Gato",font="Helvetica 80 bold")
    eti.place(x=50,y=50)
    
    str_pregs=StringVar()
    str_resp1=StringVar()
    str_resp2=StringVar()
    str_resp3=StringVar()
    str_resp4=StringVar()
    seleccion=()

    def bloqueo():
        b00.config(state=DISABLED,bg="yellow")
        b01.config(state=DISABLED,bg="yellow")
        b02.config(state=DISABLED,bg="yellow")
        b10.config(state=DISABLED,bg="yellow")
        b11.config(state=DISABLED,bg="yellow")
        b12.config(state=DISABLED,bg="yellow")
        b20.config(state=DISABLED,bg="yellow")
        b21.config(state=DISABLED,bg="yellow")
        b22.config(state=DISABLED,bg="yellow")


    def b1():
        global turno,g1
        if turno==1:
            b00.config(state=DISABLED,bg="red")  
            turno=turno+1
            g1="X"
        elif turno==2:
            b00.config(state=DISABLED,bg="green")  
            turno=turno+1
            g1="O"
        if turno>2:
            turno=1 
        gano() 

    def b2():
        global turno,g2
        if turno==1:
            b01.config(state=DISABLED,bg="red")  
            turno=turno+1
            g2="X"
        elif turno==2:
            b01.config(state=DISABLED,bg="green")  
            turno=turno+1
            g2="O"
        if turno>2:
            turno=1  
        gano()

    def b3():
        global turno,g3
        if turno==1:
            b02.config(state=DISABLED,bg="red")  
            turno=turno+1
            g3="X"
        elif turno==2:
            b02.config(state=DISABLED,bg="green")  
            turno=turno+1
            g3="O"
        if turno>2:
            turno=1
        gano()

    def b4():
        global turno,g4
        if turno==1:
            b10.config(state=DISABLED,bg="red")  
            turno=turno+1
            g4="X"
        elif turno==2:
            b10.config(state=DISABLED,bg="green")  
            turno=turno+1
            g4="O"
        if turno>2:
            turno=1
        gano()

    def b5():
        global turno,g5
        if turno==1:
            b11.config(state=DISABLED,bg="red")  
            turno=turno+1
            g5="X"
        elif turno==2:
            b11.config(state=DISABLED,bg="green")  
            turno=turno+1
            g5="O"
        if turno>2:
            turno=1
        gano()

    def b6():
        global turno,g6
        if turno==1:
            b12.config(state=DISABLED,bg="red")  
            turno=turno+1
            g6="X"
        elif turno==2:
            b12.config(state=DISABLED,bg="green")  
            turno=turno+1
            g6="O"
        if turno>2:
            turno=1
        gano()

    def b7():
        global turno,g7
        if turno==1:
            b20.config(state=DISABLED,bg="red")  
            turno=turno+1
            g7="X"
        elif turno==2:
            b20.config(state=DISABLED,bg="green")  
            turno=turno+1
            g7="O"
        if turno>2:
            turno=1
        gano()

    def b8():
        global turno,g8
        if turno==1:
            b21.config(state=DISABLED,bg="red")  
            turno=turno+1
            g8="X"
        elif turno==2:
            b21.config(state=DISABLED,bg="green")  
            turno=turno+1
            g8="O"
        if turno>2:
            turno=1
        gano()
        
    def b9():
        global turno,g9
        if turno==1:
            b22.config(state=DISABLED,bg="red")  
            turno=turno+1
            g9="X"
        elif turno==2:
            b22.config(state=DISABLED,bg="green")  
            turno=turno+1
            g9="O"
        if turno>2:
            turno=1
        gano()
    
    def gano():
        if (g1=="X" and g2=="X" and g3=="X") or (g4=="X" and g5=="X" and g6=="X") or (g7=="X" and g8=="X" and g9=="X") or (g1=="X" and g4=="X" and g7=="X") or (g2=="X" and g5=="X" and g8=="X") or (g3=="X" and g6=="X" and g9=="X") or (g1=="X" and g5=="X" and g9=="X") or (g3=="X" and g5=="X" and g7=="X"):
            messagebox.showinfo(message="Gano X")
            bloqueo()
            b23.place(x=200,y=10)
        elif (g1=="O" and g2=="O" and g3=="O") or (g4=="O" and g5=="O" and g6=="O") or (g7=="O" and g8=="O" and g9=="O") or (g1=="O" and g4=="O" and g7=="O") or (g2=="O" and g5=="O" and g8=="O") or (g3=="O" and g6=="O" and g9=="O") or (g1=="O" and g5=="O" and g9=="O") or (g3=="O" and g5=="O" and g7=="O"):
            messagebox.showinfo(message="Gano O")
            bloqueo()
            b23.place(x=200,y=10)

    

    eti = Label(pant ,bg="gold", text="Categoria", font='helvetica 18 bold')
    eti.place(x=20 , y=420)

    pre=Label(pant, text='Pregunta',bg='Light sky blue', font='helvetica 14 bold')
    pre.place(x=20, y=500)
    str_pregs.set('')
    pre_ent=Entry(pant, textvariable=str_pregs, font='helvetica 18 bold', bg='white',width=60, state=DISABLED)
    pre_ent.place(x=115,y=500)

    cat=Label(pant, text='Categoria',bg='light sky blue', font='helvetica 14 bold')
    cat.place(x=20, y=420)
#260

    str_resp1.set("")
    re1=Button(pant,textvariable=str_resp1,font='helvetica 14 bold ', bg='white', fg='black', width=20)
    re1.place(x=20,y=570)

    str_resp2.set("")
    re2=Button(pant,textvariable=str_resp2,font='helvetica 14 bold ', bg='white', fg='black', width=20)
    re2.place(x=280,y=570)

    str_resp3.set("")
    re3=Button(pant,textvariable=str_resp3,font='helvetica 14 bold ', bg='white', fg='black', width=20)
    re3.place(x=540,y=570)

    str_resp4.set("")
    re4=Button(pant,textvariable=str_resp4,font='helvetica 14 bold ', bg='white', fg='black', width=20)
    re4.place(x=800,y=570)

    rei=Button(pant,text='Reiniciar',font='helvetica 14 bold',bg='white',fg='black')
    rei.place(x=900,y=270)

    sal=Button(pant, text='Salir',command=pant.destroy,font='helvetica 14 bold',bg='white',fg='black')
    sal.place(x=1025,y=270)

    mod_ju=Button(pant,text='Modificar Jugador',font='helvetica 14 bold',bg='white', fg='black')
    mod_ju.place(x=900,y=320)

    cam_per=Button(pant,text='Cambiar Personaje',font='helvetica 14 bold',bg='white', fg='black')
    cam_per.place(x=900,y=370)

    b00=Button(pant,command=b1,font="Helvetica 18 bold",bg="blue",fg="black",width=3)
    b00.place(x=350,y=120)
    
    b01=Button(pant,command=b2,font="Helvetica 18 bold",bg="blue",fg="black",width=3)
    b01.place(x=420,y=120)

    b02=Button(pant,command=b3,font="Helvetica 18 bold",bg="blue",fg="black",width=3)
    b02.place(x=490,y=120)

    b10=Button(pant,command=b4,font="Helvetica 18 bold",bg="blue",fg="black",width=3)
    b10.place(x=350,y=190)

    b11=Button(pant,command=b5,font="Helvetica 18 bold",bg="blue",fg="black",width=3)
    b11.place(x=420,y=190)

    b12=Button(pant,command=b6,font="Helvetica 18 bold",bg="blue",fg="black",width=3)
    b12.place(x=490,y=190)

    b20=Button(pant,command=b7,font="Helvetica 18 bold",bg="blue",fg="black",width=3)
    b20.place(x=350,y=260)

    b21=Button(pant,command=b8,font="Helvetica 18 bold",bg="blue",fg="black",width=3)
    b21.place(x=420,y=260)

    b22=Button(pant,command=b9,font="Helvetica 18 bold",bg="blue",fg="black",width=3)
    b22.place(x=490,y=260)

    b23=Button(pant,command=gano,font="Helvetica 18 bold",bg="blue",fg="black",width=3)
    b23.place(x=3000,y=3000)

    pant.mainloop()